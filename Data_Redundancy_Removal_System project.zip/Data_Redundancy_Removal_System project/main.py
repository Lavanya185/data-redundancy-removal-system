
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, EmailStr
import sqlite3
import hashlib

app = FastAPI()

conn = sqlite3.connect("database.db", check_same_thread=False)
cursor = conn.cursor()

cursor.execute('''
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    email TEXT UNIQUE,
    phone TEXT UNIQUE,
    hash_value TEXT
)
''')
conn.commit()

class User(BaseModel):
    name: str
    email: EmailStr
    phone: str

def generate_hash(name, email, phone):
    data = f"{name}{email}{phone}".encode()
    return hashlib.sha256(data).hexdigest()

@app.post("/add-data")
def add_data(user: User):
    name = user.name.strip().lower()
    email = user.email.strip().lower()
    phone = user.phone.strip()

    hash_val = generate_hash(name, email, phone)

    cursor.execute("SELECT * FROM users WHERE email=? OR phone=? OR hash_value=?",
                   (email, phone, hash_val))
    if cursor.fetchone():
        raise HTTPException(status_code=400, detail="Duplicate or false positive data found")

    cursor.execute("INSERT INTO users (name, email, phone, hash_value) VALUES (?,?,?,?)",
                   (name, email, phone, hash_val))
    conn.commit()

    return {"status": "success", "message": "Unique data stored successfully"}
