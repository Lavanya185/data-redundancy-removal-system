
# Data Redundancy Removal System

## Run Instructions
1. Install dependencies:
   pip install -r requirements.txt

2. Start server:
   uvicorn main:app --reload

3. Test API:
   POST http://127.0.0.1:8000/add-data
